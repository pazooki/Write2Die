#ifndef T1HA0_DISABLED
#define T1HA_IA32AES_NAME t1ha0_ia32aes_avx2
#include "t1ha0_ia32aes_b.h"
#endif /* T1HA0_DISABLED */
